/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

#include <zephyr/kernel.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/pm/device.h>
#include <zephyr/device.h>

#include <zephyr/settings/settings.h>

#define NON_CONNECTABLE_DEVICE_NAME "BlueJoule"


static const struct bt_le_adv_param *adv_param = BT_LE_ADV_PARAM(BT_LE_ADV_OPT_USE_IDENTITY, 1600, 1600, NULL);

static const struct bt_data non_connectable_ad_data[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, BT_LE_AD_NO_BREDR),
    BT_DATA_BYTES(BT_DATA_MANUFACTURER_DATA, 0xd3, 0x08, 0xff),
	BT_DATA(BT_DATA_NAME_COMPLETE, NON_CONNECTABLE_DEVICE_NAME,
		sizeof(NON_CONNECTABLE_DEVICE_NAME) - 1),
};



int main(void)
{
	int err;
#if 1 && IS_ENABLED(CONFIG_BOARD_NRF54L15DK)
	/* Allow RRAMC to go into poweroff mode during System on idle for lower power consumption at a penalty of 9us extra RRAM ready time */
	NRF_RRAMC->POWER.LOWPOWERCONFIG = (RRAMC_POWER_LOWPOWERCONFIG_MODE_PowerOff << RRAMC_POWER_LOWPOWERCONFIG_MODE_Pos);
	NRF_MEMCONF->POWER[0].CONTROL = 0x80;
	NRF_MEMCONF->POWER[0].RET = 0x80;
	NRF_MEMCONF->POWER[0].RET2 = 0x00;
	NRF_MEMCONF->POWER[1].CONTROL = 0;
	NRF_MEMCONF->POWER[1].RET = 0;
	NRF_MEMCONF->POWER[1].RET2 = 0;
#endif


	err = bt_enable(NULL);


	err = bt_le_adv_start(adv_param, non_connectable_ad_data, ARRAY_SIZE(non_connectable_ad_data), NULL, 0);
	if (err) {
		return 0;
	}


    k_msleep(100);

}

