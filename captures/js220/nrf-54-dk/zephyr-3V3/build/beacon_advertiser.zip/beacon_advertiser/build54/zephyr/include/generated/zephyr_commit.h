#ifndef _ZEPHYR_COMMIT_H_
#define _ZEPHYR_COMMIT_H_

/*  values come from cmake/version.cmake
 * BUILD_COMMIT related  values will be 'git rev-parse',
 * alternatively user defined BUILD_VERSION.
 */

#define ZEPHYR_COMMIT                   f791c49f492c
#define ZEPHYR_COMMIT_STRING            "f791c49f492c"

#endif /* _ZEPHYR_COMMIT_H_ */
