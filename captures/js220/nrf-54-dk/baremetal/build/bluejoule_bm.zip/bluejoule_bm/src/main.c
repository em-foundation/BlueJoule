/*
 * Copyright (c) 2025 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */
 #include <stdint.h>
#include <errno.h>
#include <string.h>
#include <bluetooth/services/common.h>
#include <bm_timer.h>
#include <ble_adv_data.h>
#include <ble_conn_params.h>
#include <ble_gap.h>
#include <ble_qwr.h>
#include <nrf_sdh.h>
#include <nrf_sdh_ble.h>
#include <nrf_soc.h>
#include <zephyr/logging/log.h>
#include <zephyr/logging/log_ctrl.h>
#include <zephyr/sys/util.h>
#include <board-config.h>

#include <zephyr/toolchain.h>
#include <zephyr/drivers/retained_mem/nrf_retained_mem.h>

#include <hal/nrf_regulators.h>
#include <helpers/nrfx_reset_reason.h>

#include <hal/nrf_gpio.h>

#if defined(CONFIG_HAS_NORDIC_RAM_CTRL)
#include <helpers/nrfx_ram_ctrl.h>
#endif

LOG_MODULE_REGISTER(app, CONFIG_BLE_PWR_PROFILING_SAMPLE_LOG_LEVEL);

/** BLE QWR instance. */
BLE_QWR_DEF(ble_qwr);

/** Advertising modes. */
enum adv_mode {
	ADV_MODE_IDLE,
	ADV_MODE_CONN,
	ADV_MODE_NONCONN,
};
/** Current advertising mode. */
static enum adv_mode adv_mode_current;
/** Advertising parameters. */static ble_gap_adv_params_t adv_params;
/* Advertising handle. */
static uint8_t adv_handle;
/* Advertising data. */static ble_gap_adv_data_t gap_adv_data;
/* Encoded advertising data. */
static uint8_t enc_adv_data[2][BLE_GAP_ADV_SET_DATA_SIZE_MAX];
/* Encoded scan response data. */
static uint8_t enc_scan_rsp_data[2][BLE_GAP_ADV_SET_DATA_SIZE_MAX];

/** Power of the SoC. */
static void poweroff(void)
{
	LOG_INF("Power off");
	while (LOG_PROCESS()) {
	}

#if defined(CONFIG_HAS_NORDIC_RAM_CTRL)
	uint8_t *ram_start;
	size_t ram_size;

#if defined(NRF_MEMORY_RAM_BASE)
	ram_start = (uint8_t *)NRF_MEMORY_RAM_BASE;
#else
	ram_start = (uint8_t *)NRF_MEMORY_RAM0_BASE;
#endif

	ram_size = 0;
#if defined(NRF_MEMORY_RAM_SIZE)
	ram_size += NRF_MEMORY_RAM_SIZE;
#endif
#if defined(NRF_MEMORY_RAM0_SIZE)
	ram_size += NRF_MEMORY_RAM0_SIZE;
#endif
#if defined(NRF_MEMORY_RAM1_SIZE)
	ram_size += NRF_MEMORY_RAM1_SIZE;
#endif
#if defined(NRF_MEMORY_RAM2_SIZE)
	ram_size += NRF_MEMORY_RAM2_SIZE;
#endif

	/* Disable retention for all memory blocks */
	nrfx_ram_ctrl_retention_enable_set(ram_start, ram_size, false);

#endif /* defined(CONFIG_HAS_NORDIC_RAM_CTRL) */

#if defined(CONFIG_RETAINED_MEM_NRF_RAM_CTRL)
	/* Restore retention for retained_mem driver regions defined in devicetree */
	(void)z_nrf_retained_mem_retention_apply();
#endif

#if defined(CONFIG_SOC_SERIES_NRF54LX)
	nrfx_reset_reason_clear(UINT32_MAX);
#endif

	nrf_regulators_system_off(NRF_REGULATORS);

	CODE_UNREACHABLE;
}

static void on_ble_evt(const ble_evt_t *evt, void *ctx)
{
	switch (evt->header.evt_id) {
	case BLE_GAP_EVT_ADV_SET_TERMINATED:

		const uint8_t reason = evt->evt.gap_evt.params.adv_set_terminated.reason;

		if (reason == BLE_GAP_EVT_ADV_SET_TERMINATED_REASON_TIMEOUT ||
		    reason == BLE_GAP_EVT_ADV_SET_TERMINATED_REASON_LIMIT_REACHED) {
			poweroff();
		}
		break;
	default:
		break;
	}
}
NRF_SDH_BLE_OBSERVER(sdh_ble, on_ble_evt, NULL, 0);

static uint16_t on_ble_qwr_evt(struct ble_qwr *qwr, const struct ble_qwr_evt *qwr_evt)
{
	switch (qwr_evt->evt_type) {
	case BLE_QWR_EVT_ERROR:
		LOG_ERR("QWR error event, nrf_error 0x%x", qwr_evt->error.reason);
		break;
	case BLE_QWR_EVT_EXECUTE_WRITE:
		LOG_INF("QWR execute write event");
		break;
	case BLE_QWR_EVT_AUTH_REQUEST:
		LOG_INF("QWR auth request event");
		break;
	}

	return BLE_GATT_STATUS_SUCCESS;
}

/* Add optional advertising data and start advertising in the given mode */
static void adv_data_update_and_start(enum adv_mode adv_mode)
{
	uint32_t err;
	ble_gap_adv_data_t new_adv_data = {0};

    uint8_t manu_data[] = {0xff}; 

    struct ble_adv_data_manufacturer adv_data_manu = {
        .company_identifier = 0x08d3,
        .data = manu_data,
        .len = 1,
    };

	struct ble_adv_data adv_data = {
		.name_type = BLE_ADV_DATA_FULL_NAME,
		.flags = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE,
        .manufacturer_data = &adv_data_manu,
	};
	struct ble_adv_data sr_data = {};

	if (adv_mode_current != ADV_MODE_IDLE) {
		err = sd_ble_gap_adv_stop(adv_handle);
		if (err != NRF_SUCCESS) {
			LOG_ERR("Failed to stop advertising, nrf_error %#x", err);
			return;
		}

		LOG_INF("Advertising stopped. Reconfiguring...");
	}

    sr_data.uuid_lists.complete.uuid = NULL;
    sr_data.uuid_lists.complete.len = 0;

    memset(&adv_params, 0, sizeof(adv_params));
    adv_params.properties.type = BLE_GAP_ADV_TYPE_NONCONNECTABLE_SCANNABLE_UNDIRECTED;
    adv_params.interval = CONFIG_BLE_PWR_PROFILING_NONCONN_ADVERTISING_INTERVAL;
    adv_params.duration = CONFIG_BLE_PWR_PROFILING_NONCONN_ADVERTISING_TIMEOUT;

	new_adv_data.adv_data.p_data =
		(new_adv_data.adv_data.p_data != enc_adv_data[0])
			? enc_adv_data[0]
			: enc_adv_data[1];

	new_adv_data.adv_data.len = BLE_GAP_ADV_SET_DATA_SIZE_MAX;

	err = ble_adv_data_encode(&adv_data, new_adv_data.adv_data.p_data,
				  &new_adv_data.adv_data.len);
	if (err) {
		return;
	}

	new_adv_data.scan_rsp_data.p_data =
		(new_adv_data.scan_rsp_data.p_data != enc_scan_rsp_data[0])
			? enc_scan_rsp_data[0]
			: enc_scan_rsp_data[1];

	new_adv_data.scan_rsp_data.len = BLE_GAP_ADV_SET_DATA_SIZE_MAX;

	err = ble_adv_data_encode(&sr_data, new_adv_data.scan_rsp_data.p_data,
				  &new_adv_data.scan_rsp_data.len);
	if (err) {
		return;
	}

	memcpy(&gap_adv_data, &new_adv_data, sizeof(gap_adv_data));

	err = sd_ble_gap_adv_set_configure(&adv_handle, &gap_adv_data, &adv_params);
	if (err) {
		LOG_ERR("Failed to set advertising data, nrf_error %#x", err);
		return;
	}

    err = sd_ble_gap_tx_power_set(BLE_GAP_TX_POWER_ROLE_ADV, 0, 0);
	if (err) {
		LOG_ERR("Failed to set power, nrf_error %#x", err);
		return;
	}

	err = sd_ble_gap_adv_start(adv_handle, CONFIG_NRF_SDH_BLE_CONN_TAG);
	if (err) {
		LOG_ERR("Failed to start advertising, nrf_error %#x", err);
		return;
	}

	adv_mode_current = adv_mode;

	LOG_INF("Advertising as %s", CONFIG_BLE_PWR_PROFILING_ADV_NAME);
}

#define ADV_NAME "BlueJoule"

static uint32_t adv_init(void)
{
	uint32_t err;
	ble_gap_conn_sec_mode_t sec_mode = {0};

	BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);
	err = sd_ble_gap_device_name_set(&sec_mode, ADV_NAME, strlen(ADV_NAME));
	if (err != NRF_SUCCESS) {
		LOG_ERR("Failed to set advertising name, nrf_error %#x", err);
		return err;
	}

	gap_adv_data.adv_data.p_data = enc_adv_data[0];
	gap_adv_data.adv_data.len = BLE_GAP_ADV_SET_DATA_SIZE_MAX;

	adv_params.properties.type = BLE_GAP_ADV_TYPE_NONCONNECTABLE_NONSCANNABLE_UNDIRECTED;
	adv_params.duration = 0;
	adv_params.interval = 1600;
	adv_params.filter_policy = BLE_GAP_ADV_FP_ANY;
	adv_params.primary_phy = BLE_GAP_PHY_AUTO;

	err = sd_ble_gap_adv_set_configure(&adv_handle, NULL, &adv_params);
	if (err != NRF_SUCCESS) {
		LOG_ERR("Failed to set GAP advertising parameters, nrf_error %#x", err);
		return err;
	}

	return NRF_SUCCESS;
}

int main(void)
{
	int err;
	struct ble_qwr_config qwr_config = {
		.evt_handler = on_ble_qwr_evt,
	};

	LOG_INF("BLE Power Profiling sample started");

	err = nrf_sdh_enable_request();
	if (err) {
		LOG_ERR("Failed to enable SoftDevice, err %d", err);
		goto idle;
	}

	LOG_INF("SoftDevice enabled");

	err = nrf_sdh_ble_enable(CONFIG_NRF_SDH_BLE_CONN_TAG);
	if (err) {
		LOG_ERR("Failed to enable BLE, err %d", err);
		goto idle;
	}

	LOG_INF("Bluetooth enabled");

	err = ble_qwr_init(&ble_qwr, &qwr_config);
	if (err) {
		LOG_ERR("Failed to initialize QWR, err %d", err);
		goto idle;
	}

	err = adv_init();
	if (err != NRF_SUCCESS) {
		LOG_ERR("Failed to initialize advertising, nrf_error %#x", err);
		goto idle;
	}

	LOG_INF("Services initialized");

	adv_data_update_and_start(ADV_MODE_NONCONN);

idle:
	while (true) {
		while (LOG_PROCESS()) {
			/* Empty. */
		}

		/* Wait for an event. */
		__WFE();

		/* Clear Event Register */
		__SEV();
		__WFE();
	}

	return 0;
}
