

#include <bcomdef.h>
#include <gapgattserver.h>
#include <gap_advertiser.h>
#include <app_main.h>
#include "ti_ble_config.h"
#include <ti/bleapp/ble_app_util/inc/bleapputil_api.h>

// The GAP profile role
uint8_t profileRole = GAP_PROFILE_BROADCASTER;
// GAP GATT Service (GGS) parameters
uint8_t attDeviceName[GAP_DEVICE_NAME_LEN]= "Basic BLE project";

uint8_t pRandomAddress[B_ADDR_LEN] = {0};

// Initiate selected profiles
void init_profiles(){
 }

GapAdv_params_t advParams1 = {
  .eventProps =   GAP_ADV_PROP_LEGACY,
  .primIntMin =   1920,
  .primIntMax =   1920,
  .primChanMap =  GAP_ADV_CHAN_37,
  .peerAddrType = PEER_ADDRTYPE_PUBLIC_OR_PUBLIC_ID,
  .peerAddr =     { 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa },
  .filterPolicy = GAP_ADV_AL_POLICY_ANY_REQ,
  .txPower =      5,
  .primPhy =      GAP_ADV_PRIM_PHY_1_MBPS,
  .secPhy =       GAP_ADV_SEC_PHY_1_MBPS,
  .sid =          0
};

uint8_t advData1[] =
{
  0x04,
  GAP_ADTYPE_LOCAL_NAME_SHORT,
  'T',
  'X',
  'N',

  0x02,
  GAP_ADTYPE_FLAGS,
  GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED | GAP_ADTYPE_FLAGS_GENERAL,



};

uint8_t scanResData1[] =
{
  0x12,
  GAP_ADTYPE_LOCAL_NAME_COMPLETE,
  'B',
  'a',
  's',
  'i',
  'c',
  ' ',
  'B',
  'L',
  'E',
  ' ',
  'p',
  'r',
  'o',
  'j',
  'e',
  'c',
  't',

  0x02,
  GAP_ADTYPE_POWER_LEVEL,
  0,



};

