

#include <bcomdef.h>
#include <gapgattserver.h>
#include <gap_advertiser.h>
#include <app_main.h>
#include "ti_ble_config.h"
#include <ti/bleapp/ble_app_util/inc/bleapputil_api.h>

// The GAP profile role
uint8_t profileRole = GAP_PROFILE_BROADCASTER;
// GAP GATT Service (GGS) parameters
uint8_t attDeviceName[GAP_DEVICE_NAME_LEN]= "Basic BLE project";

uint8_t pRandomAddress[B_ADDR_LEN] = {0};

// Initiate selected profiles
void init_profiles(){
 }

GapAdv_params_t advParams1 = {
  .eventProps =   GAP_ADV_PROP_LEGACY,
  .primIntMin =   1600,
  .primIntMax =   1600,
  .primChanMap =  GAP_ADV_CHAN_ALL,
  .peerAddrType = PEER_ADDRTYPE_PUBLIC_OR_PUBLIC_ID,
  .peerAddr =     { 0xaa, 0xaa, 0xbb, 0xbb, 0xcc, 0xcc },
  .filterPolicy = GAP_ADV_AL_POLICY_ANY_REQ,
  .txPower =      0,
  .primPhy =      GAP_ADV_PRIM_PHY_1_MBPS,
  .secPhy =       GAP_ADV_SEC_PHY_1_MBPS,
  .sid =          0
};

uint8_t advData1[] =
{
  0x0a,
  GAP_ADTYPE_LOCAL_NAME_SHORT,
  'B',
  'l',
  'u',
  'e',
  'J',
  'o',
  'u',
  'l',
  'e',

  0x02,
  GAP_ADTYPE_FLAGS,
  GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED | GAP_ADTYPE_FLAGS_GENERAL,



  0x05,
  GAP_ADTYPE_MANUFACTURER_SPECIFIC,
  //Company Identifier
  0xd3,
  0x08,

  //Additional Data
  0xff,

};

